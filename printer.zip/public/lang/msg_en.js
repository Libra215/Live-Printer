var MSG_GIFT = "Mersi |username| pentru cadou";
var MSG_WINNER = "Felicitari lui |username| pentru castigarea rundei.";
var MSG_TEST = "verik";